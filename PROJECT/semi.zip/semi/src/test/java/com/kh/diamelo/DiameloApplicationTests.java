package com.kh.diamelo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiameloApplicationTests {

	@Test
	void contextLoads() {
	}

}
